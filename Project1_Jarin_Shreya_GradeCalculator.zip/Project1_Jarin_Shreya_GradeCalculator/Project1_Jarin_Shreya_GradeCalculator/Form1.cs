﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1_Jarin_Shreya_GradeCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Assigning variables
            string input = txtScore.Text;
            int score;

            // Trying to convert the input into scores
            // If valid input, show them in the average label
            if (int.TryParse(input, out score))
            {
                // Check if score is valid
                if (score < 0 || score > 100)
                {
                    MessageBox.Show("Please put a valid score: 0-100.");
                    return;
                }

                lblAvg.Text = score.ToString();

                // Creating if statements to assign the range of scores
                if (score >= 90) lblGrade.Text = "A";
                else if (score >= 80) lblGrade.Text = "B";
                else if (score >= 70) lblGrade.Text = "C";
                else if (score >= 60) lblGrade.Text = "D";
                else if (score >= 0) lblGrade.Text = "F";

                // Show message
                MessageBox.Show("Done with Calculation");
            }
        }

        // Coding for Clear button
        private void btnClear_Click(object sender, EventArgs e)
        {
            // Assign the variables
            txtScore.Clear();
            lblAvg.Text = "-";
            lblGrade.Text = "-";
            txtScore.Focus();

            // Show message for clear
            MessageBox.Show("Cleared!");
        }
    }
}
